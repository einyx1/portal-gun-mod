import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const geoDir = path.join(root, "src", "main", "resources", "assets", "portalgun", "geo");
const meshDir = path.join(root, "src", "main", "resources", "assets", "portalgun", "mesh");
fs.mkdirSync(meshDir, { recursive: true });

for (const name of [
  "standard_portal_gun.geo.json",
  "prototype_portal_gun.geo.json",
  "evil_morty_portal_gun.geo.json",
  "prime_portal_gun.geo.json",
]) {
  const geoPath = path.join(geoDir, name);
  const meshPath = path.join(meshDir, name);
  const model = JSON.parse(fs.readFileSync(geoPath, "utf8"));
  const hasPolyMesh = (model["minecraft:geometry"] ?? []).some(geometry =>
    (geometry.bones ?? []).some(bone => bone.poly_mesh));

  // Preserve the complete Bedrock source for the custom polygon renderer.
  if (hasPolyMesh) fs.copyFileSync(geoPath, meshPath);
  else if (!fs.existsSync(meshPath)) throw new Error(`Missing raw mesh backup for ${name}`);

  // GeckoLib 4.8.4 cannot deserialize Blockbench's nested poly_mesh arrays.
  // It still handles all cubes, pivots and animations after this field is removed.
  for (const geometry of model["minecraft:geometry"] ?? []) {
    for (const bone of geometry.bones ?? []) delete bone.poly_mesh;
  }

  fs.writeFileSync(geoPath, JSON.stringify(model, null, 2) + "\n", "utf8");
}
