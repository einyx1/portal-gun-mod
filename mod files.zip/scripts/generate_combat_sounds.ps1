$soundRoot=Join-Path $PSScriptRoot "..\src\main\resources\assets\portalgun\sounds"
New-Item -ItemType Directory -Force -Path $soundRoot | Out-Null
function Tone([string]$name,[string]$source,[string]$filter){
    & ffmpeg -loglevel error -y -f lavfi -i $source -af $filter -c:a libvorbis -q:a 5 (Join-Path $soundRoot "$name.ogg")
}
Tone "weapon_laser" "sine=frequency=1180:duration=0.20:sample_rate=44100" "volume=0.55,afade=t=out:st=0.08:d=0.12"
Tone "weapon_plasma" "sine=frequency=185:duration=0.48:sample_rate=44100" "tremolo=f=32:d=0.75,volume=0.8,afade=t=out:st=0.2:d=0.28"
Tone "weapon_freeze" "anoisesrc=color=white:duration=0.55:sample_rate=44100" "highpass=f=1800,lowpass=f=6500,volume=0.23,afade=t=out:st=0.15:d=0.4"
Tone "weapon_mindblower" "sine=frequency=440:duration=0.7:sample_rate=44100" "chorus=0.6:0.8:40:0.5:1.4:0.4,volume=0.55,afade=t=out:st=0.35:d=0.35"
Tone "weapon_neutrino" "sine=frequency=58:duration=1.8:sample_rate=44100" "tremolo=f=7:d=0.6,volume=0.95,afade=t=in:d=0.15,afade=t=out:st=1.15:d=0.65"
Tone "purge_missile" "anoisesrc=color=pink:duration=0.48:sample_rate=44100" "lowpass=f=1900,volume=0.42,afade=t=out:st=0.18:d=0.3"
Tone "purge_flame" "anoisesrc=color=brown:duration=0.6:sample_rate=44100" "highpass=f=140,lowpass=f=2800,volume=0.55,afade=t=out:st=0.3:d=0.3"
Tone "purge_shock" "sine=frequency=1500:duration=0.26:sample_rate=44100" "tremolo=f=55:d=0.9,volume=0.55,afade=t=out:st=0.1:d=0.16"
Tone "purge_blade" "anoisesrc=color=white:duration=0.24:sample_rate=44100" "highpass=f=2400,volume=0.28,afade=t=out:st=0.06:d=0.18"
Tone "purge_saw" "sine=frequency=115:duration=0.42:sample_rate=44100" "tremolo=f=38:d=0.85,volume=0.7,afade=t=out:st=0.22:d=0.2"
