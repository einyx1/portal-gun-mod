Add-Type -AssemblyName System.Drawing

$assetRoot = Join-Path $PSScriptRoot "..\src\main\resources\assets\portalgun\textures"
$itemRoot = Join-Path $assetRoot "item"
$armorRoot = Join-Path $assetRoot "models\armor"
New-Item -ItemType Directory -Force -Path $itemRoot | Out-Null
New-Item -ItemType Directory -Force -Path $armorRoot | Out-Null

function Brush([string]$hex) { New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml($hex)) }
function Pen([string]$hex, [int]$width=1) { New-Object System.Drawing.Pen ([System.Drawing.ColorTranslator]::FromHtml($hex)), $width }
function Save-Weapon([string]$name,[string]$body,[string]$energy,[int]$kind) {
    $bmp=[System.Drawing.Bitmap]::new(32,32,[System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g=[System.Drawing.Graphics]::FromImage($bmp);$g.Clear([System.Drawing.Color]::Transparent)
    $outline=Brush "#111318";$metal=Brush $body;$glow=Brush $energy;$white=Brush "#E9FFFF"
    if($kind -eq 4){
        $g.FillEllipse($outline,5,5,22,22);$g.FillEllipse($metal,7,7,18,18)
        for($i=0;$i -lt 12;$i++){ $a=$i*[Math]::PI/6;$x=[int](15+[Math]::Cos($a)*8);$y=[int](15+[Math]::Sin($a)*8);$g.FillEllipse($glow,$x,$y,3,3) }
        $g.FillEllipse($glow,13,13,6,6);$g.FillRectangle($white,15,14,2,3)
    } elseif($kind -eq 5){
        $g.DrawLine((Pen "#0A0B10" 5),7,26,25,5);$g.DrawLine((Pen $body 3),7,26,25,5);$g.FillRectangle($glow,4,23,8,5);$g.FillRectangle($white,7,22,2,2)
    } else {
        $g.FillRectangle($outline,4,9,23,10);$g.FillRectangle($metal,6,10,19,7)
        $g.FillRectangle($outline,18,17,6,9);$g.FillRectangle($metal,19,17,4,7)
        $g.FillRectangle($glow,3,11,5,5);$g.FillRectangle($glow,11,11,8,3)
        if($kind -eq 1){$g.FillEllipse($glow,20,8,8,8)}
        if($kind -eq 2){$g.FillRectangle($white,7,12,15,2);$g.FillRectangle($glow,24,10,5,6)}
        if($kind -eq 3){$g.FillEllipse($glow,9,8,9,9);$g.FillEllipse($white,12,11,3,3)}
    }
    $bmp.Save((Join-Path $itemRoot "$name.png"),[System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose();$bmp.Dispose()
}

Save-Weapon "laser_gun" "#6D7378" "#FF3B1F" 0
Save-Weapon "plasma_pistol" "#333845" "#A72EFF" 1
Save-Weapon "freeze_ray" "#8BA9B7" "#2DE4FF" 2
Save-Weapon "mindblower_gun" "#4D3F62" "#FFCF35" 3
Save-Weapon "neutrino_bomb" "#252934" "#D92EFF" 4
Save-Weapon "rick_lightsaber" "#636A70" "#27EFFF" 5

# Dense material atlases for the GeckoLib weapon geometry. Unlike flat item
# sprites these must cover every UV region so no cube face becomes invisible.
function Save-WeaponAtlas([string]$name,[string]$metal,[string]$dark,[string]$energy){
    $bmp=[System.Drawing.Bitmap]::new(32,32,[System.Drawing.Imaging.PixelFormat]::Format32bppArgb);$g=[System.Drawing.Graphics]::FromImage($bmp)
    $g.Clear([System.Drawing.ColorTranslator]::FromHtml($dark));$g.FillRectangle((Brush $metal),1,1,30,30)
    for($y=2;$y -lt 32;$y+=6){$g.FillRectangle((Brush $dark),0,$y,32,2)}
    for($x=3;$x -lt 32;$x+=8){$g.FillRectangle((Brush "#10141A"),$x,0,2,32)}
    $g.FillRectangle((Brush $energy),2,3,13,3);$g.FillRectangle((Brush $energy),18,10,11,4);$g.FillRectangle((Brush "#E8F4F6"),3,3,4,1)
    $g.FillRectangle((Brush "#090B0F"),2,20,11,9);$g.FillRectangle((Brush "#5D6570"),4,21,7,2);$g.FillRectangle((Brush $energy),22,22,7,7)
    $bmp.Save((Join-Path $itemRoot "$name.png"),[System.Drawing.Imaging.ImageFormat]::Png);$g.Dispose();$bmp.Dispose()
}
Save-WeaponAtlas "laser_gun" "#69727B" "#171A20" "#FF351F"
Save-WeaponAtlas "plasma_pistol" "#4B5060" "#15131D" "#A735FF"
Save-WeaponAtlas "freeze_ray" "#9DB7C3" "#17232A" "#27DCF5"
Save-WeaponAtlas "mindblower_gun" "#6C5537" "#211A17" "#FFB51E"

function Save-ArmorIcon([string]$name,[int]$piece){
    $bmp=[System.Drawing.Bitmap]::new(32,32,[System.Drawing.Imaging.PixelFormat]::Format32bppArgb);$g=[System.Drawing.Graphics]::FromImage($bmp);$g.Clear([System.Drawing.Color]::Transparent)
    $dark=Brush "#17191F";$orange=Brush "#D55C19";$cyan=Brush "#33DDEB";$gold=Brush "#F4B52C"
    if($piece -eq 0){$g.FillRectangle($dark,7,6,18,17);$g.FillRectangle($orange,9,8,14,4);$g.FillRectangle($cyan,10,13,5,4);$g.FillRectangle($cyan,18,13,4,4)}
    if($piece -eq 1){$g.FillPolygon($dark,[System.Drawing.Point[]]@((New-Object System.Drawing.Point 6,5),(New-Object System.Drawing.Point 26,5),(New-Object System.Drawing.Point 23,27),(New-Object System.Drawing.Point 9,27)));$g.FillRectangle($orange,10,8,12,5);$g.FillRectangle($cyan,14,14,4,8)}
    if($piece -eq 2){$g.FillRectangle($dark,8,5,16,11);$g.FillRectangle($dark,8,14,6,14);$g.FillRectangle($dark,18,14,6,14);$g.FillRectangle($gold,9,7,14,3)}
    if($piece -eq 3){$g.FillRectangle($dark,6,12,9,12);$g.FillRectangle($dark,18,12,9,12);$g.FillRectangle($orange,7,19,8,4);$g.FillRectangle($orange,19,19,8,4)}
    $bmp.Save((Join-Path $itemRoot "$name.png"),[System.Drawing.Imaging.ImageFormat]::Png);$g.Dispose();$bmp.Dispose()
}
Save-ArmorIcon "purge_helmet" 0;Save-ArmorIcon "purge_chestplate" 1;Save-ArmorIcon "purge_leggings" 2;Save-ArmorIcon "purge_boots" 3

function Save-ArmorLayer([string]$name,[bool]$legs){
    $bmp=[System.Drawing.Bitmap]::new(64,32,[System.Drawing.Imaging.PixelFormat]::Format32bppArgb);$g=[System.Drawing.Graphics]::FromImage($bmp);$g.Clear([System.Drawing.Color]::Transparent)
    $dark=Brush "#17191F";$metal=Brush "#3D414B";$orange=Brush "#D55C19";$cyan=Brush "#31DCE8";$gold=Brush "#F3B62C"
    $g.FillRectangle($dark,0,0,64,32)
    for($x=0;$x -lt 64;$x+=8){$g.FillRectangle($(if(($x/8)%2-eq0){$metal}else{$dark}),$x,0,8,32)}
    $g.FillRectangle($orange,8,8,16,3);$g.FillRectangle($orange,20,20,20,3);$g.FillRectangle($cyan,14,12,4,5);$g.FillRectangle($gold,44,8,8,3)
    $bmp.Save((Join-Path $armorRoot "$name.png"),[System.Drawing.Imaging.ImageFormat]::Png);$g.Dispose();$bmp.Dispose()
}
Save-ArmorLayer "purge_suit_layer_1" $false;Save-ArmorLayer "purge_suit_layer_2" $true

# 64x64 material atlas for the final 3D Purge Suit.
$purge=[System.Drawing.Bitmap]::new(64,64,[System.Drawing.Imaging.PixelFormat]::Format32bppArgb);$pg=[System.Drawing.Graphics]::FromImage($purge)
$pg.Clear([System.Drawing.ColorTranslator]::FromHtml("#15181E"));$pg.FillRectangle((Brush "#343B45"),1,1,62,62)
for($y=0;$y -lt 64;$y+=8){$pg.FillRectangle((Brush "#171A20"),0,$y,64,2)}
for($x=0;$x -lt 64;$x+=8){$pg.FillRectangle((Brush "#222730"),$x,0,2,64)}
$pg.FillRectangle((Brush "#DB5F1C"),2,2,22,6);$pg.FillRectangle((Brush "#F1A92C"),30,16,24,4)
$pg.FillRectangle((Brush "#25DFEC"),32,2,10,10);$pg.FillRectangle((Brush "#E8FFFF"),34,3,3,7)
$pg.FillRectangle((Brush "#101216"),0,24,28,16);$pg.FillRectangle((Brush "#555E69"),2,26,24,3)
$pg.FillRectangle((Brush "#D65119"),32,24,16,12);$pg.FillRectangle((Brush "#22262D"),35,27,10,6)
$pg.FillRectangle((Brush "#28D9E5"),48,24,8,4);$pg.FillRectangle((Brush "#0A0C10"),48,32,16,24)
$pg.FillRectangle((Brush "#E88724"),50,36,10,3);$pg.FillRectangle((Brush "#68727C"),0,42,32,14)
$pg.FillRectangle((Brush "#171A20"),4,46,24,3);$pg.FillRectangle((Brush "#E45F1D"),36,42,20,10)
$pg.FillRectangle((Brush "#252A33"),38,44,16,6);$pg.FillRectangle((Brush "#222730"),0,56,32,8)
$pg.FillRectangle((Brush "#F0A72B"),2,58,26,3);$pg.FillRectangle((Brush "#20D7E3"),34,56,26,6)
$purge.Save((Join-Path $armorRoot "purge_suit.png"),[System.Drawing.Imaging.ImageFormat]::Png);$pg.Dispose();$purge.Dispose()

# Transparent vanilla armor atlas: an ordinary cloth eyepatch, with no glowing
# lens, circuitry or metal parts. The combat prediction is an item ability, not
# a visible cybernetic device.
$eye=[System.Drawing.Bitmap]::new(64,32,[System.Drawing.Imaging.PixelFormat]::Format32bppArgb);$eg=[System.Drawing.Graphics]::FromImage($eye);$eg.Clear([System.Drawing.Color]::Transparent)
$black=Brush "#07080B";$cloth=Brush "#151820";$edge=Brush "#30343D"
$eg.FillRectangle($black,8,11,7,5);$eg.FillRectangle($cloth,9,12,5,3);$eg.FillRectangle($edge,10,12,3,1)
$eg.FillRectangle($black,0,10,9,1);$eg.FillRectangle($black,14,10,10,1)
$eye.Save((Join-Path $armorRoot "evil_morty_eyepatch_layer_1.png"),[System.Drawing.Imaging.ImageFormat]::Png);$eg.Dispose();$eye.Dispose()

# Compact texture used by the dedicated GeckoLib eyepatch geometry.
$worn=[System.Drawing.Bitmap]::new(16,16,[System.Drawing.Imaging.PixelFormat]::Format32bppArgb);$wg=[System.Drawing.Graphics]::FromImage($worn)
$wg.Clear([System.Drawing.ColorTranslator]::FromHtml("#08090C"));$wg.FillRectangle((Brush "#181B22"),1,1,12,5);$wg.FillRectangle((Brush "#353943"),2,1,8,1);$wg.FillRectangle((Brush "#111319"),0,7,16,5)
$worn.Save((Join-Path $armorRoot "evil_morty_eyepatch_worn.png"),[System.Drawing.Imaging.ImageFormat]::Png);$wg.Dispose();$worn.Dispose()

$cell=[System.Drawing.Bitmap]::new(32,32,[System.Drawing.Imaging.PixelFormat]::Format32bppArgb);$cg=[System.Drawing.Graphics]::FromImage($cell);$cg.Clear([System.Drawing.Color]::Transparent)
$cg.FillRectangle((Brush "#11141A"),8,4,16,24);$cg.FillRectangle((Brush "#515964"),10,6,12,20);$cg.FillRectangle((Brush "#26E5F2"),12,9,8,13);$cg.FillRectangle((Brush "#E9FFFF"),14,10,2,10);$cg.FillRectangle((Brush "#D9A928"),12,3,8,4)
$cell.Save((Join-Path $itemRoot "weapon_energy_cell.png"),[System.Drawing.Imaging.ImageFormat]::Png);$cg.Dispose();$cell.Dispose()
